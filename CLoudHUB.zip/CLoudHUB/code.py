import os, time, socket, threading, qrcode, base64
from flask import Flask, request, render_template, send_from_directory, jsonify
from io import BytesIO

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 12 * 1024 * 1024 * 1024

UPLOAD_FOLDER = 'shared_files'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
CLIPBOARD_FILE = "clipboard.txt"

if not os.path.exists(CLIPBOARD_FILE):
    with open(CLIPBOARD_FILE, "w", encoding="utf-8") as f: f.write("")

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except: IP = '127.0.0.1'
    finally: s.close()
    return IP

def cleanup_worker():
    while True:
        now = time.time()
        for f in os.listdir(UPLOAD_FOLDER):
            path = os.path.join(UPLOAD_FOLDER, f)
            if os.path.getmtime(path) < now - 3600:
                try: os.remove(path)
                except: pass
        time.sleep(60)

threading.Thread(target=cleanup_worker, daemon=True).start()

@app.route('/')
def index():
    ip = get_ip()
    link = f"http://{ip}:5000"
    qr = qrcode.make(link)
    buffered = BytesIO()
    qr.save(buffered, format="PNG")
    qr_base64 = base64.b64encode(buffered.getvalue()).decode()
    return render_template('index.html', qr_code=qr_base64, server_ip=link)

@app.route('/files')
def list_files():
    files = []
    total_size = 0
    for f in os.listdir(UPLOAD_FOLDER):
        path = os.path.join(UPLOAD_FOLDER, f)
        f_size = os.path.getsize(path)
        total_size += f_size
        ext = f.lower().split('.')[-1]
        # Добавил ico сюда
        files.append({
            'name': f, 'time': os.path.getmtime(path),
            'is_img': ext in ['png', 'jpg', 'jpeg', 'gif', 'webp', 'ico'],
            'is_vid': ext in ['mp4', 'webm', 'ogg'],
            'size': f_size
        })
    files.sort(key=lambda x: x['time'], reverse=True)
    limit = 12 * 1024 * 1024 * 1024 
    return jsonify({'files': files, 'space': {'used': total_size, 'percent': min((total_size/limit)*100, 100)}})

@app.route('/clipboard', methods=['GET', 'POST'])
def handle_clipboard():
    if request.method == 'POST':
        text = request.json.get('text', '')
        with open(CLIPBOARD_FILE, "w", encoding="utf-8") as f: f.write(text)
        return "OK"
    with open(CLIPBOARD_FILE, "r", encoding="utf-8") as f: return f.read()

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' in request.files:
        f = request.files['file']
        f.save(os.path.join(UPLOAD_FOLDER, f.filename))
    return "OK"

@app.route('/download/<path:filename>')
def download_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/delete/<path:filename>', methods=['POST'])
def delete_file(filename):
    path = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(path): os.remove(path); return "OK"
    return "Err", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)